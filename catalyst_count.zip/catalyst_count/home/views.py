
from django.shortcuts import render, HttpResponse, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
import csv
from django.http import JsonResponse
from django.db import transaction
from django.contrib import messages
from .forms import UploadCSVForm
from django.shortcuts import render
from .forms import QueryBuilderForm
from django.views.decorators.csrf import csrf_exempt
from .models import Company

@login_required(login_url='login')
def HomePage(request):
    return render(request, 'home.html')


def SignupPage(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        email = request.POST.get('email')
        pass1 = request.POST.get('password1')
        pass2 = request.POST.get('password2')

        if pass1 != pass2:
            return HttpResponse("Your password and confrom password are not Same!!")
        else:

            my_user = User.objects.create_user(uname, email, pass1)
            my_user.save()
            return redirect('login')

    return render(request, 'signup.html')


def LoginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        pass1 = request.POST.get('pass')
        user = authenticate(request, username=username, password=pass1)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return HttpResponse("Username or Password is incorrect!!!")

    return render(request, 'login.html')


def LogoutPage(request):
    logout(request)
    return redirect('login')



@csrf_exempt
def upload_csv(request):
    if request.method == 'POST':
        form = UploadCSVForm(request.POST, request.FILES)
        if form.is_valid():
            csv_file = request.FILES['csv_file']

            chunk_size = 500

            try:
                with transaction.atomic():
                    # process the csv file in chunks
                    for chunk in csv_file.chunks(chunk_size):
                        decoded_chunk = chunk.decode('utf-8')
                        reader = csv.DictReader(decoded_chunk.splitlines())

                        companies_to_create = []

                        for row in reader:
                            cleaned_row = {key.strip().replace(' ', '_'): value.strip() if value is not None else None
                                           for key, value in row.items()}
                            cleaned_row = {key: value for key, value in cleaned_row.items() if key is not None and value is not None}
                            if '' in cleaned_row:
                                del cleaned_row['']


                            for numeric_field in ['year_founded', 'current_employee_estimate', 'total_employee_estimate']:
                                if cleaned_row.get(numeric_field) is not None and cleaned_row[numeric_field].isdigit():
                                    cleaned_row[numeric_field] = int(cleaned_row[numeric_field])
                                else:
                                    cleaned_row[numeric_field] = None

                            companies_to_create.append(Company(**cleaned_row))

                            if len(companies_to_create) >= 1000:
                                Company.objects.bulk_create(companies_to_create)
                                companies_to_create = []

                        Company.objects.bulk_create(companies_to_create)

            except csv.Error as e:
                return JsonResponse({'error': f'Error processing file: {str(e)}'}, status=400)

            messages.success(request, 'File uploaded and data added to the database!')
            return JsonResponse({'success': 'CSV file uploaded and data added to the database!'})

    else:
        form = UploadCSVForm()

    return render(request, 'upload_csv.html', {'form': form})



@csrf_exempt
def query_builder(request):
    companies = Company.objects.all()

    if request.method == 'GET':
        form = QueryBuilderForm(request.GET)
        if form.is_valid():
            name = form.cleaned_data.get('name')
            domain = form.cleaned_data.get('domain')
            year_founded = form.cleaned_data.get('year_founded')
            industry = form.cleaned_data.get('industry')
            size_range = form.cleaned_data.get('size_range')
            locality = form.cleaned_data.get('locality')
            country = form.cleaned_data.get('country')
            linkedin_url = form.cleaned_data.get('linkedin_url')
            current_employee_estimate = form.cleaned_data.get('current_employee_estimate')
            total_employee_estimate = form.cleaned_data.get('total_employee_estimate')

            if name:
                companies = companies.filter(name__icontains=name)
            if year_founded:
                companies = companies.filter(year_founded__icontains=year_founded)
            if industry:
                companies = companies.filter(industry__icontains=industry)
            if locality:
                companies = companies.filter(locality__icontains=locality)
            if country:
                companies = companies.filter(country__icontains=country)
            if current_employee_estimate:
                companies = companies.filter(current_employee_estimate__icontains=current_employee_estimate)
            if total_employee_estimate:
                companies = companies.filter(total_employee_estimate__icontains=total_employee_estimate)


    else:
        form = QueryBuilderForm()

    return render(request, 'query_builder.html', {'companies': companies, 'form': form})

