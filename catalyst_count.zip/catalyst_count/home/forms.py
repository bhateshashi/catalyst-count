
from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import AuthenticationForm


class LoginForm(AuthenticationForm):
    class Meta:
        model = get_user_model()
        fields = ['username', 'password']

class QueryBuilderForm(forms.Form):
    name = forms.CharField(required=False)
    year_founded = forms.IntegerField(required=False)
    industry = forms.CharField(required=False)
    locality = forms.CharField(required=False)
    country = forms.CharField(required=False)
    current_employee_estimate = forms.IntegerField(required=False)
    total_employee_estimate = forms.IntegerField(required=False)

class UploadCSVForm(forms.Form):
    csv_file = forms.FileField()

