from django.urls import path
from .views import HomePage,SignupPage,LoginPage,LogoutPage,query_builder,upload_csv


urlpatterns = [
    path('signup',SignupPage,name='signup'),
    path('login/',LoginPage,name='login'),
    path('',HomePage,name='home'),
    path('logout/',LogoutPage,name='logout'),
    path('query-builder/', query_builder, name='query_builder'),
    path('upload_csv/', upload_csv, name='upload_csv'),



]